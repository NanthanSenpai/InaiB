package com.inaib.pro

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentCallbacks2
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.URLUtil
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.ContentBlocking
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.GeckoView
import org.mozilla.geckoview.StorageController
import org.mozilla.geckoview.WebResponse

/**
 * InaiB Pro: a browser with its OWN engine (Mozilla GeckoView, the engine inside Firefox).
 * It does not use the phone's Android System WebView, so it behaves the same on every phone.
 *
 * Low-RAM design: only one GeckoSession is alive at a time. Background tabs keep a small
 * saved state (history + scroll) and are rebuilt when selected. The session is closed when
 * the app is in the background and Android is short of memory.
 */
@Suppress("DEPRECATION")
class MainActivity : Activity() {

    private class Tab(
        var url: String,
        var title: String = "",
        val priv: Boolean = false,
        var state: GeckoSession.SessionState? = null
    )

    private companion object {
        const val MAX_TABS = 8
        const val REQ_STORAGE = 2
        var runtime: GeckoRuntime? = null // GeckoRuntime can only be created once per process
    }

    private lateinit var prefs: Prefs
    private lateinit var geckoView: GeckoView
    private lateinit var root: View
    private lateinit var topBar: View
    private lateinit var urlBar: EditText
    private lateinit var progress: ProgressBar
    private lateinit var btnReload: ImageButton
    private lateinit var tabCount: TextView

    private val tabs = ArrayList<Tab>()
    private var current = 0
    private var session: GeckoSession? = null
    private var canGoBack = false
    private var loading = false
    private var stopped = false
    private var pendingDownload: (() -> Unit)? = null

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        root = findViewById(R.id.root)
        topBar = findViewById(R.id.top_bar)
        geckoView = findViewById(R.id.geckoview)
        urlBar = findViewById(R.id.url_bar)
        progress = findViewById(R.id.progress)
        btnReload = findViewById(R.id.btn_reload)
        tabCount = findViewById(R.id.btn_tabs)

        root.setOnApplyWindowInsetsListener { v, insets ->
            v.setPadding(0, insets.systemWindowInsetTop, 0, insets.systemWindowInsetBottom)
            insets
        }

        val rt = runtime ?: GeckoRuntime.create(
            this,
            GeckoRuntimeSettings.Builder()
                .javaScriptEnabled(prefs.javascript)
                .build()
        ).also { runtime = it }
        applyRuntimeSettings(rt)

        urlBar.setOnEditorActionListener { v, actionId, event ->
            val enter = event != null && event.keyCode == KeyEvent.KEYCODE_ENTER &&
                event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_GO || enter) {
                load(Search.resolve(v.text.toString(), prefs.engine, prefs.lang))
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(v.windowToken, 0)
                v.clearFocus()
                true
            } else false
        }
        btnReload.setOnClickListener {
            if (loading) session?.stop() else session?.reload()
        }
        tabCount.setOnClickListener { showTabs() }
        findViewById<View>(R.id.btn_menu).setOnClickListener { showMenu() }

        for (u in prefs.savedTabs.take(MAX_TABS)) tabs.add(Tab(u))
        if (tabs.isEmpty()) tabs.add(Tab(Search.START_URL))
        current = prefs.savedCurrent.coerceIn(0, tabs.size - 1)

        intent?.dataString?.let { linked ->
            if (tabs.size >= MAX_TABS) tabs.removeAt(tabs.size - 1)
            tabs.add(Tab(linked))
            current = tabs.size - 1
        }
        tabCount.text = tabs.size.toString()
    }

    override fun onStart() {
        super.onStart()
        stopped = false
        if (session == null) openSession(tabs[current])
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.dataString?.let { openNewTab(it, false) }
    }

    override fun onStop() {
        super.onStop()
        stopped = true
        // Private tabs are never written to disk.
        val keep = tabs.filter { !it.priv }
        val cur = tabs.getOrNull(current)
        prefs.saveTabs(keep.map { it.url }, keep.indexOf(cur).coerceAtLeast(0))
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (stopped && level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND) closeSession(true)
    }

    override fun onDestroy() {
        closeSession(false)
        super.onDestroy()
    }

    override fun onBackPressed() {
        when {
            canGoBack -> session?.goBack()
            tabs.size > 1 -> closeCurrentTab()
            else -> super.onBackPressed()
        }
    }

    // ---------------------------------------------------------------- engine settings

    private fun applyRuntimeSettings(rt: GeckoRuntime) {
        val s = rt.settings
        s.setJavaScriptEnabled(prefs.javascript)
        s.setLocales(Search.locales(prefs.lang))
        s.setPreferredColorScheme(
            when (prefs.theme) {
                1 -> GeckoRuntimeSettings.COLOR_SCHEME_LIGHT
                2 -> GeckoRuntimeSettings.COLOR_SCHEME_DARK
                else -> GeckoRuntimeSettings.COLOR_SCHEME_SYSTEM
            }
        )
        // Built-in ad / tracker blocking (Firefox Enhanced Tracking Protection lists).
        val cb = s.contentBlocking
        when (prefs.protection) {
            0 -> {
                cb.setAntiTracking(ContentBlocking.AntiTracking.NONE)
                cb.setCookieBehavior(ContentBlocking.CookieBehavior.ACCEPT_ALL)
            }
            1 -> {
                cb.setAntiTracking(
                    ContentBlocking.AntiTracking.AD or ContentBlocking.AntiTracking.ANALYTIC or
                        ContentBlocking.AntiTracking.SOCIAL or ContentBlocking.AntiTracking.CRYPTOMINING or
                        ContentBlocking.AntiTracking.FINGERPRINTING
                )
                cb.setCookieBehavior(ContentBlocking.CookieBehavior.ACCEPT_NON_TRACKERS)
            }
            else -> {
                cb.setAntiTracking(
                    ContentBlocking.AntiTracking.AD or ContentBlocking.AntiTracking.ANALYTIC or
                        ContentBlocking.AntiTracking.SOCIAL or ContentBlocking.AntiTracking.CRYPTOMINING or
                        ContentBlocking.AntiTracking.FINGERPRINTING or ContentBlocking.AntiTracking.CONTENT
                )
                cb.setCookieBehavior(ContentBlocking.CookieBehavior.ACCEPT_NON_TRACKERS)
            }
        }
    }

    // ---------------------------------------------------------------- sessions and tabs

    private fun openSession(tab: Tab) {
        val rt = runtime ?: return
        val st = GeckoSessionSettings.Builder()
            .usePrivateMode(tab.priv)
            .userAgentMode(
                if (prefs.desktop) GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
                else GeckoSessionSettings.USER_AGENT_MODE_MOBILE
            )
            .viewportMode(
                if (prefs.desktop) GeckoSessionSettings.VIEWPORT_MODE_DESKTOP
                else GeckoSessionSettings.VIEWPORT_MODE_MOBILE
            )
            .build()
        val s = GeckoSession(st)
        s.setContentDelegate(contentDelegate)
        s.setProgressDelegate(progressDelegate)
        s.setNavigationDelegate(navigationDelegate)
        s.open(rt)
        geckoView.setSession(s)
        session = s
        canGoBack = false
        val saved = tab.state
        if (saved != null) s.restoreState(saved) else s.loadUri(tab.url)
        showUrl(tab)
        tabCount.text = tabs.size.toString()
        root.setBackgroundResource(if (tab.priv) android.R.color.black else R.color.bar)
    }

    private fun closeSession(saveState: Boolean) {
        val s = session ?: return
        if (!saveState) tabs.getOrNull(current)?.state = null
        geckoView.releaseSession()
        s.close()
        session = null
        loading = false
    }

    private fun switchTo(i: Int) {
        if (i == current && session != null) return
        closeSession(true)
        current = i
        openSession(tabs[i])
    }

    private fun openNewTab(url: String, priv: Boolean) {
        if (tabs.size >= MAX_TABS) {
            toast("Tab limit reached ($MAX_TABS)")
            return
        }
        closeSession(true)
        tabs.add(Tab(url, priv = priv))
        current = tabs.size - 1
        openSession(tabs[current])
    }

    private fun closeCurrentTab() {
        closeSession(false)
        if (tabs.size == 1) {
            tabs[0] = Tab(Search.START_URL)
            current = 0
        } else {
            tabs.removeAt(current)
            current = current.coerceAtMost(tabs.size - 1)
        }
        openSession(tabs[current])
    }

    private fun tabLabel(t: Tab): String {
        val base = when {
            t.url.startsWith("resource://android/assets/start") -> "New tab"
            t.title.isNotBlank() -> t.title
            else -> t.url.removePrefix("https://")
        }
        return (if (t.priv) "🕶 " else "") + base
    }

    private fun showTabs() {
        val titles = tabs.mapIndexed { i, t -> (if (i == current) "● " else "") + tabLabel(t) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Tabs (${tabs.size}/$MAX_TABS)")
            .setItems(titles) { _, i -> switchTo(i) }
            .setPositiveButton("New tab") { _, _ -> openNewTab(Search.START_URL, false) }
            .setNegativeButton("Close this tab") { _, _ -> closeCurrentTab() }
            .setNeutralButton("Private tab") { _, _ -> openNewTab(Search.START_URL, true) }
            .show()
    }

    private fun load(url: String) {
        tabs.getOrNull(current)?.let { it.url = url; it.state = null }
        session?.loadUri(url)
    }

    private fun showUrl(tab: Tab) {
        urlBar.setText(if (tab.url.startsWith("resource://android/assets/start")) "" else tab.url.removePrefix("https://"))
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------------------------------------------------------------- delegates

    private val progressDelegate = object : GeckoSession.ProgressDelegate {
        override fun onPageStart(session: GeckoSession, url: String) {
            if (session !== this@MainActivity.session) return
            loading = true
            btnReload.setImageResource(R.drawable.ic_close)
            progress.progress = 5
            progress.visibility = View.VISIBLE
            tabs.getOrNull(current)?.let {
                it.url = url
                if (!urlBar.hasFocus()) showUrl(it)
            }
        }

        override fun onPageStop(session: GeckoSession, success: Boolean) {
            if (session !== this@MainActivity.session) return
            loading = false
            btnReload.setImageResource(R.drawable.ic_reload)
            progress.visibility = View.GONE
        }

        override fun onProgressChange(session: GeckoSession, progress: Int) {
            if (session !== this@MainActivity.session) return
            this@MainActivity.progress.progress = progress
        }

        override fun onSessionStateChange(session: GeckoSession, sessionState: GeckoSession.SessionState) {
            if (session !== this@MainActivity.session) return
            tabs.getOrNull(current)?.state = sessionState
        }
    }

    private val contentDelegate = object : GeckoSession.ContentDelegate {
        override fun onTitleChange(session: GeckoSession, title: String?) {
            tabs.getOrNull(current)?.title = title ?: ""
        }

        override fun onExternalResponse(session: GeckoSession, response: WebResponse) {
            val ct = response.headers["content-type"]
            startDownload(response.uri, null, response.headers["content-disposition"], ct)
        }

        override fun onFullScreen(session: GeckoSession, fullScreen: Boolean) {
            topBar.visibility = if (fullScreen) View.GONE else View.VISIBLE
            window.decorView.systemUiVisibility = if (fullScreen) {
                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            } else View.SYSTEM_UI_FLAG_VISIBLE
        }

        override fun onContextMenu(
            session: GeckoSession,
            screenX: Int,
            screenY: Int,
            element: GeckoSession.ContentDelegate.ContextElement
        ) {
            val link = element.linkUri ?: element.srcUri ?: return
            showLinkMenu(link)
        }
    }

    private val navigationDelegate = object : GeckoSession.NavigationDelegate {
        override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
            this@MainActivity.canGoBack = canGoBack
        }

        override fun onLoadRequest(
            session: GeckoSession,
            request: GeckoSession.NavigationDelegate.LoadRequest
        ): GeckoResult<AllowOrDeny>? {
            val scheme = Uri.parse(request.uri).scheme ?: "https"
            return when (scheme) {
                "http", "https", "about", "file", "data", "blob", "resource", "javascript", "view-source" ->
                    GeckoResult.fromValue(AllowOrDeny.ALLOW)
                else -> {
                    openExternal(request.uri) // tel:, mailto:, upi:, whatsapp:, intent: ...
                    GeckoResult.fromValue(AllowOrDeny.DENY)
                }
            }
        }

        override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession>? {
            // Pop-ups the engine's blocker lets through open as a normal tab.
            openNewTab(uri, tabs.getOrNull(current)?.priv == true)
            return null
        }
    }

    // ---------------------------------------------------------------- downloads, links, share

    private fun startDownload(url: String, ua: String?, contentDisposition: String?, mime: String?) {
        if (!url.startsWith("http")) {
            toast("This download type isn't supported yet")
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingDownload = { startDownload(url, ua, contentDisposition, mime) }
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQ_STORAGE)
            return
        }
        try {
            val name = URLUtil.guessFileName(url, contentDisposition, mime)
            val req = DownloadManager.Request(Uri.parse(url))
                .setTitle(name)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            if (!mime.isNullOrEmpty()) req.setMimeType(mime)
            (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            toast("Downloading $name")
        } catch (e: Exception) {
            toast("Download failed")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_STORAGE) {
            val run = pendingDownload
            pendingDownload = null
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) run?.invoke()
            else toast("Storage permission is needed to save downloads")
        }
    }

    private fun openExternal(url: String) {
        try {
            val i = if (url.startsWith("intent:")) {
                Intent.parseUri(url, Intent.URI_INTENT_SCHEME).apply {
                    addCategory(Intent.CATEGORY_BROWSABLE)
                    component = null
                    selector = null
                }
            } else Intent(Intent.ACTION_VIEW, Uri.parse(url))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            toast("No app found to open this link")
        }
    }

    private fun showLinkMenu(url: String) {
        val priv = tabs.getOrNull(current)?.priv == true
        AlertDialog.Builder(this)
            .setTitle(url.take(80))
            .setItems(arrayOf("Open in new tab", "Copy link address", "Share")) { _, which ->
                when (which) {
                    0 -> openNewTab(url, priv)
                    1 -> {
                        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                            .setPrimaryClip(ClipData.newPlainText("url", url))
                        toast("Copied")
                    }
                    2 -> share(url)
                }
            }
            .show()
    }

    private fun share(text: String) {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(i, "Share"))
    }

    // ---------------------------------------------------------------- menu and customisation

    private fun protLabel() = arrayOf("Off", "Standard", "Strict")[prefs.protection]
    private fun themeLabel() = arrayOf("System", "Light", "Dark")[prefs.theme]
    private fun onOff(b: Boolean) = if (b) "ON" else "OFF"

    private fun showMenu() {
        val items = arrayOf(
            "New tab",
            "New private tab",
            "Forward",
            "Share page",
            "Ad & tracker blocking: ${protLabel()}",
            "Desktop site: ${onOff(prefs.desktop)}",
            "JavaScript: ${onOff(prefs.javascript)}",
            "Theme: ${themeLabel()}",
            "Search engine: ${Search.engines[prefs.engine].name}",
            "Search language: ${Search.langs[prefs.lang].label}",
            "Clear browsing data",
            "Make InaiB Pro your default browser"
        )
        AlertDialog.Builder(this)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> openNewTab(Search.START_URL, false)
                    1 -> openNewTab(Search.START_URL, true)
                    2 -> session?.goForward()
                    3 -> share(tabs[current].url)
                    4 -> choose("Ad & tracker blocking", arrayOf("Off", "Standard", "Strict"), prefs.protection) {
                        prefs.protection = it
                        runtime?.let { rt -> applyRuntimeSettings(rt) }
                        session?.reload()
                    }
                    5 -> {
                        prefs.desktop = !prefs.desktop
                        reopenCurrent()
                    }
                    6 -> {
                        prefs.javascript = !prefs.javascript
                        runtime?.let { applyRuntimeSettings(it) }
                        session?.reload()
                    }
                    7 -> choose("Theme", arrayOf("System", "Light", "Dark"), prefs.theme) {
                        prefs.theme = it
                        runtime?.let { rt -> applyRuntimeSettings(rt) }
                    }
                    8 -> choose("Search engine", Search.engines.map { it.name }.toTypedArray(), prefs.engine) {
                        prefs.engine = it
                    }
                    9 -> choose("Search language", Search.langs.map { it.label }.toTypedArray(), prefs.lang) {
                        prefs.lang = it
                        runtime?.let { rt -> applyRuntimeSettings(rt) }
                    }
                    10 -> confirmClear()
                    11 -> try {
                        startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
                    } catch (e: Exception) {
                        toast("Open Settings > Apps > Default apps > Browser app")
                    }
                }
            }
            .show()
    }

    /** User-agent mode is fixed when a session is created, so rebuild it with the same history. */
    private fun reopenCurrent() {
        closeSession(true)
        openSession(tabs[current])
    }

    private fun choose(title: String, names: Array<String>, selected: Int, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(names, selected) { d, which ->
                onPick(which)
                d.dismiss()
            }
            .show()
    }

    private fun confirmClear() {
        AlertDialog.Builder(this)
            .setTitle("Clear browsing data?")
            .setMessage("Removes cookies, cache, history and saved site data.")
            .setPositiveButton("Clear") { _, _ ->
                runtime?.storageController?.clearData(StorageController.ClearFlags.ALL)
                tabs.forEach { it.state = null }
                toast("Browsing data cleared")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
