package com.inaib.pro

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("inaib_pro", Context.MODE_PRIVATE)

    /** 0 = off, 1 = standard (ads, analytics, social, miners, fingerprinting), 2 = strict (also content trackers). */
    var protection: Int = sp.getInt("protection", 1).coerceIn(0, 2)
        set(v) { field = v; sp.edit().putInt("protection", v).apply() }

    var desktop: Boolean = sp.getBoolean("desktop", false)
        set(v) { field = v; sp.edit().putBoolean("desktop", v).apply() }

    var javascript: Boolean = sp.getBoolean("js", true)
        set(v) { field = v; sp.edit().putBoolean("js", v).apply() }

    /** 0 = follow system, 1 = light, 2 = dark */
    var theme: Int = sp.getInt("theme", 0).coerceIn(0, 2)
        set(v) { field = v; sp.edit().putInt("theme", v).apply() }

    var engine: Int = sp.getInt("engine", 0).coerceIn(0, Search.engines.size - 1)
        set(v) { field = v; sp.edit().putInt("engine", v).apply() }

    var lang: Int = sp.getInt("lang", 0).coerceIn(0, Search.langs.size - 1)
        set(v) { field = v; sp.edit().putInt("lang", v).apply() }

    val savedTabs: List<String>
        get() = (sp.getString("tabs", "") ?: "").split('\n').filter { it.isNotEmpty() }

    val savedCurrent: Int
        get() = sp.getInt("current", 0)

    fun saveTabs(urls: List<String>, current: Int) {
        sp.edit().putString("tabs", urls.joinToString("\n")).putInt("current", current).apply()
    }
}
