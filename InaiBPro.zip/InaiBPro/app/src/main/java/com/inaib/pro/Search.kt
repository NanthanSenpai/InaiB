package com.inaib.pro

import android.net.Uri

class Engine(val name: String, val template: String)

/** code = language code used by the engine, label = name shown in the menu. */
class Lang(val label: String, val code: String)

/** India-pinned search engines and Indian result languages. */
object Search {
    const val START_URL = "resource://android/assets/start.html"

    val engines = listOf(
        Engine("Google (India)", "https://www.google.co.in/search?q={q}&gl=in&hl={l}"),
        Engine("Bing (India)", "https://www.bing.com/search?q={q}&cc=IN&setlang={t}"),
        Engine("DuckDuckGo (India)", "https://duckduckgo.com/?q={q}&kl=in-en"),
        Engine("Yahoo (India)", "https://in.search.yahoo.com/search?p={q}")
    )

    val langs = listOf(
        Lang("English", "en"),
        Lang("हिन्दी (Hindi)", "hi"),
        Lang("தமிழ் (Tamil)", "ta"),
        Lang("తెలుగు (Telugu)", "te"),
        Lang("മലയാളം (Malayalam)", "ml"),
        Lang("ಕನ್ನಡ (Kannada)", "kn"),
        Lang("বাংলা (Bengali)", "bn"),
        Lang("मराठी (Marathi)", "mr")
    )

    private val SCHEME = Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://")
    private val HOST = Regex("^([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,}(:\\d+)?([/?#].*)?$")
    private val LOCAL = Regex("^(localhost|\\d{1,3}(\\.\\d{1,3}){3})(:\\d+)?([/?#].*)?$")

    fun resolve(raw: String, engine: Int, lang: Int): String {
        val s = raw.trim()
        if (s.isEmpty()) return START_URL
        if (SCHEME.containsMatchIn(s)) return s
        if (!s.contains(' ')) {
            if (LOCAL.matches(s)) return "http://$s"
            if (HOST.matches(s)) return "https://$s"
        }
        val l = langs[lang]
        return engines[engine].template
            .replace("{q}", Uri.encode(s))
            .replace("{l}", l.code)
            .replace("{t}", l.code + "-IN")
    }

    /** Locale list given to the engine so sites prefer Indian-language content. */
    fun locales(lang: Int): Array<String> {
        val c = langs[lang].code
        return if (c == "en") arrayOf("en-IN", "en-US") else arrayOf("$c-IN", "en-IN", "en-US")
    }
}
