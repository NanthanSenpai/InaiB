plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// The GeckoView version is passed in by the build: ./gradlew assembleDebug -PgeckoVersion=xxx
val geckoVersion: String = (project.findProperty("geckoVersion") as String?)
    ?: error("Missing -PgeckoVersion=<version>. See README.")

android {
    namespace = "com.inaib.pro"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.inaib.pro"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "2.0"
        ndk {
            // 32-bit and 64-bit ARM phones. (Removes x86 emulator libs to save ~40 MB.)
            abiFilters += listOf("armeabi-v7a", "arm64-v8a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false // GeckoView ships its own rules; keep it simple
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    implementation("org.mozilla.geckoview:geckoview-omni:$geckoVersion")
}
