# InaiB Pro: a browser with its own engine

Uses Mozilla's GeckoView (the Firefox engine) bundled inside the app, so it does NOT depend on Android System WebView.

Build: `./gradlew assembleDebug -PgeckoVersion=<version from https://maven.mozilla.org/maven2/org/mozilla/geckoview/geckoview-omni/>`
(The GitHub workflow in build-yml.txt finds the newest version automatically.)

Features: built-in ad/tracker blocking (Off/Standard/Strict), private tabs, desktop site, JavaScript switch, theme, Indian search engines and result languages, tabs, downloads, fullscreen video, external app links.

Not included yet: VPN, uBlock Origin extension, bookmarks/history UI, sync.
